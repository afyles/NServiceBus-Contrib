﻿using NServiceBus;

namespace $safeprojectname$
{
    public class EndpointConfig : IConfigureThisEndpoint, AsA_Publisher
    {
    }
}
