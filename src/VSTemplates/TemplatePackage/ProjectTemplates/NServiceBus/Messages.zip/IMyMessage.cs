﻿using NServiceBus;

namespace $safeprojectname$
{
    public interface $safeitemname$ : IMessage
    {
    }
}
