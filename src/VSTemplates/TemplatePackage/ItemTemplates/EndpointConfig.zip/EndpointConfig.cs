﻿using NServiceBus;

namespace $rootnamespace$
{
    public class $safeitemname$ : IConfigureThisEndpoint, AsA_Server
    {
    }
}
